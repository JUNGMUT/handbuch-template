#!/usr/bin/env python3
"""
Baut das finale Kunden-Handbuch:

    Cover (aus basic.pdf, Footer-Label -> "Schulungsunterlage · <Kunde>")
  + NEUES Inhaltsverzeichnis (Basis-Kapitel + Kunden-Kapitel)
  + Basis-Seiten aus basic.pdf (ab Seite 3)
  + Kunden-Kapitel (content.html, Seitenzählung läuft nahtlos weiter)

Nutzung:
    python3 assemble.py \
        --basic   <repo>/basic.pdf \
        --content <build>/content.html \
        --client  "Kundenname" \
        --out     <build>/<kunde>_Handbuch.pdf

Optional:
    --manifest <repo>/basic.json   (Default: basic.json neben basic.pdf;
                                    fehlt sie, wird die Kapitelliste aus der
                                    basic.pdf gelesen)
    --no-cover-label               Cover-Footer unverändert lassen

content.html muss <link rel="stylesheet" href="style.css"> referenzieren
(setup_build.py legt style.css + Fonts im selben Ordner ab) und enthält NUR
die Kunden-Kapitel als <section class="chapter"> mit
<h1 class="chapter-title"><span class="chapter-num">10</span>Titel</h1>.
Unterkapitel fürs Inhaltsverzeichnis: chapter-num mit Punkt, z. B. "10.1".
"""
import argparse
import html as htmllib
import io
import json
import os
import re
import subprocess
import sys
from html.parser import HTMLParser

from pypdf import PdfReader, PdfWriter
from weasyprint import HTML

PT_PER_PX = 0.75


# ---------------------------------------------------------------- manifest
def derive_manifest(basic_pdf: str) -> dict:
    """Fallback: Kapitel aus der basic.pdf lesen (große Unbounded-Headlines)."""
    out = subprocess.run(["pdftotext", "-bbox", basic_pdf, "-"],
                         capture_output=True, text=True, check=True).stdout
    chapters = []
    for i, page in enumerate(out.split("<page ")[1:], start=1):
        words = re.findall(r'<word xMin="([\d.]+)" yMin="([\d.]+)" xMax="[\d.]+" '
                           r'yMax="([\d.]+)">([^<]*)</word>', page)
        big = [htmllib.unescape(w[3]) for w in words
               if 21 < float(w[2]) - float(w[1]) < 24]
        if i > 2 and big and re.match(r"^\d+(\.\d+)*$", big[0]):
            chapters.append({"num": big[0], "title": " ".join(big[1:]), "page": i})
    return {"cover_page": 1, "toc_page": 2, "chapters": chapters}


def load_manifest(basic_pdf: str, manifest_path: str | None) -> dict:
    path = manifest_path or os.path.join(os.path.dirname(os.path.abspath(basic_pdf)), "basic.json")
    if os.path.exists(path):
        with open(path, encoding="utf-8") as f:
            return json.load(f)
    print(f"[hinweis] {path} nicht gefunden – Kapitel werden aus der basic.pdf gelesen.")
    return derive_manifest(basic_pdf)


# ---------------------------------------------------------- content parsing
class ChapterParser(HTMLParser):
    """Sammelt alle <h1 class="chapter-title"> mit Nummer + Titel."""

    def __init__(self):
        super().__init__()
        self.items, self._in_h1, self._in_num = [], False, False
        self._num, self._title = "", ""

    def handle_starttag(self, tag, attrs):
        cls = dict(attrs).get("class", "") or ""
        if tag == "h1" and "chapter-title" in cls.split():
            self._in_h1, self._num, self._title = True, "", ""
        elif self._in_h1 and tag == "span" and "chapter-num" in cls.split():
            self._in_num = True

    def handle_endtag(self, tag):
        if tag == "span" and self._in_num:
            self._in_num = False
        elif tag == "h1" and self._in_h1:
            self._in_h1 = False
            self.items.append({"num": self._num.strip(),
                               "title": re.sub(r"\s+", " ", self._title).strip()})

    def handle_data(self, data):
        if self._in_num:
            self._num += data
        elif self._in_h1:
            self._title += data


def level(num: str) -> int:
    return num.count(".") + 1


# ---------------------------------------------------------------- rendering
def render_customer(content_html: str, base_url: str, first_page_no: int):
    with open(content_html, encoding="utf-8") as f:
        src = f.read()
    inject = (f"<style>@page:first {{ counter-reset: page {first_page_no}; }}"
              "h1:not(.chapter-title), h2, h3, h4 { bookmark-level: none; }"
              "h1.chapter-title { bookmark-level: 1; }</style>")
    src = src.replace("</head>", inject + "</head>", 1) if "</head>" in src else inject + src
    doc = HTML(string=src, base_url=base_url).render()
    pages = [b[1][0] for b in doc.make_bookmark_tree()]  # 0-basiert
    buf = io.BytesIO()
    doc.write_pdf(buf)
    return PdfReader(io.BytesIO(buf.getvalue())), pages


def render_toc(entries: list, base_url: str):
    rows = []
    for e in entries:
        sub = ' class="sub"' if level(e["num"]) > 1 else ""
        rows.append(f'<li{sub}><span class="num">{htmllib.escape(e["num"])}</span>'
                    f'<span class="label">{htmllib.escape(e["title"])}</span></li>')
    for dense in ["", "dense-1", "dense-2", "dense-3"]:
        src = ('<!DOCTYPE html><html lang="de"><head><meta charset="utf-8">'
               '<link rel="stylesheet" href="style.css"></head><body>'
               f'<div class="toc-page {dense}"><h1>Inhalt</h1><ul class="toc-list">'
               + "\n".join(rows) + "</ul></div></body></html>")
        doc = HTML(string=src, base_url=base_url).render()
        if len(doc.pages) == 1:
            buf = io.BytesIO()
            doc.write_pdf(buf)
            return PdfReader(io.BytesIO(buf.getvalue())), dense or "normal"
    sys.exit(f"FEHLER: Inhaltsverzeichnis passt mit {len(entries)} Einträgen nicht auf eine "
             "Seite. Unterkapitel (z. B. 10.1) zusammenfassen oder weniger Kapitel anlegen.")


def render_cover_label(label: dict, text: str, base_url: str, page_w: float, page_h: float):
    """Überdeckt das alte Footer-Label auf dem Cover und setzt den neuen Text."""
    pad = 2.5
    right = page_w - label["x_right"]
    box_w = label.get("cover_width", 260)
    src = f"""<!DOCTYPE html><html><head><meta charset="utf-8"><style>
    @font-face {{ font-family: 'BodyFont'; src: url('assets/fonts/body.ttf'); font-weight: 100 900; }}
    @page {{ size: {page_w}pt {page_h}pt; margin: 0; }}
    body {{ margin: 0; }}
    .mask {{ position: absolute; right: {right - pad}pt; top: {label['y_top'] - pad}pt;
             width: {box_w}pt; height: {label['y_bottom'] - label['y_top'] + 2 * pad}pt;
             background: {label.get('background', '#0030d0')}; }}
    .txt {{ position: absolute; right: {right}pt; top: {label['y_top']}pt; white-space: nowrap;
            font-family: 'BodyFont'; font-size: {label.get('font_size_px', 10.5)}px;
            line-height: normal; color: {label.get('color', '#ffffff')}; }}
    </style></head><body><div class="mask"></div><div class="txt">{htmllib.escape(text)}</div></body></html>"""
    buf = io.BytesIO()
    HTML(string=src, base_url=base_url).write_pdf(buf)
    return PdfReader(io.BytesIO(buf.getvalue())).pages[0]


# ------------------------------------------------------------------- main
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--basic", required=True)
    ap.add_argument("--content", required=True)
    ap.add_argument("--client", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--manifest", default=None)
    ap.add_argument("--base-url", default=None, help="Default: Ordner von content.html")
    ap.add_argument("--no-cover-label", action="store_true")
    args = ap.parse_args()

    base_url = args.base_url or os.path.dirname(os.path.abspath(args.content))
    if not os.path.exists(os.path.join(base_url, "style.css")):
        sys.exit(f"FEHLER: {base_url}/style.css fehlt – zuerst setup_build.py ausführen.")

    basic = PdfReader(args.basic)
    manifest = load_manifest(args.basic, args.manifest)
    cover_i = manifest.get("cover_page", 1) - 1
    toc_i = manifest.get("toc_page", 2) - 1
    n_basic = len(basic.pages)
    base_entries = manifest["chapters"]

    # Kunden-Kapitel
    parser = ChapterParser()
    with open(args.content, encoding="utf-8") as f:
        parser.feed(f.read())
    cust_entries = parser.items
    if not cust_entries:
        sys.exit("FEHLER: keine <h1 class=\"chapter-title\"> in content.html gefunden.")

    last_base = max(int(e["num"].split(".")[0]) for e in base_entries)
    top_nums = [int(e["num"].split(".")[0]) for e in cust_entries]
    expected = last_base + 1
    if top_nums[0] != expected:
        print(f"[WARNUNG] Erstes Kunden-Kapitel hat Nummer {top_nums[0]}, erwartet {expected}.")

    cust_pdf, cust_pages = render_customer(args.content, base_url, n_basic + 1)
    if len(cust_pages) != len(cust_entries):
        print("[WARNUNG] Anzahl Kapitel-Bookmarks != Anzahl Kapitel-Titel – Outline evtl. ungenau.")

    # TOC
    all_entries = base_entries + cust_entries
    toc_pdf, toc_mode = render_toc(all_entries, base_url)

    # Zusammenbauen
    w = PdfWriter()
    cover = basic.pages[cover_i]
    label = manifest.get("cover_label")
    if label and not args.no_cover_label:
        text = label.get("template", "Schulungsunterlage · {client}").format(client=args.client)
        cover.merge_page(render_cover_label(label, text, base_url,
                                            float(cover.mediabox.width),
                                            float(cover.mediabox.height)))
    w.add_page(cover)
    w.add_page(toc_pdf.pages[0])
    for i in range(n_basic):
        if i not in (cover_i, toc_i):
            w.add_page(basic.pages[i])
    offset_cust = n_basic  # 0-basierter Index der ersten Kunden-Seite im Ergebnis
    for p in cust_pdf.pages:
        w.add_page(p)

    # Outline (Lesezeichen)
    w.add_outline_item("Inhalt", 1)
    parents = {}
    page_of = []
    for e in base_entries:
        page_of.append((e, e["page"] - 1))
    for e, p in zip(cust_entries, cust_pages):
        page_of.append((e, offset_cust + p))
    for e, p in page_of:
        title = f'{e["num"]} {e["title"]}'
        if level(e["num"]) == 1:
            parents[e["num"]] = w.add_outline_item(title, p)
        else:
            w.add_outline_item(title, p, parent=parents.get(e["num"].split(".")[0]))

    title = manifest.get("title", "WordPress Redaktionshandbuch")
    w.add_metadata({"/Title": f"{title} – {args.client} – JUNGMUT", "/Author": "JUNGMUT"})
    w.compress_identical_objects(remove_identicals=True, remove_orphans=True)
    os.makedirs(os.path.dirname(os.path.abspath(args.out)), exist_ok=True)
    with open(args.out, "wb") as f:
        w.write(f)

    print(json.dumps({
        "out": args.out,
        "pages_total": len(w.pages),
        "basic_pages": n_basic,
        "customer_pages": len(cust_pdf.pages),
        "first_customer_page": n_basic + 1,
        "toc_entries": len(all_entries),
        "toc_layout": toc_mode,
        "customer_chapters": [{"num": e["num"], "title": e["title"], "page": offset_cust + p + 1}
                              for e, p in zip(cust_entries, cust_pages)],
        "size_mb": round(os.path.getsize(args.out) / 1e6, 2),
    }, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
