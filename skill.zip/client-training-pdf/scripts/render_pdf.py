#!/usr/bin/env python3
"""
Nutzung:
    python3 render_pdf.py <input.html> <output.pdf> [--base-url <dir>]

<base-url> ist das Verzeichnis, relativ zu dem style.css / assets/ im HTML
referenziert werden (i. d. R. der Output-Ordner selbst, siehe SKILL.md).
"""
import argparse
from weasyprint import HTML


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("input_html")
    ap.add_argument("output_pdf")
    ap.add_argument("--base-url", default=".")
    args = ap.parse_args()

    HTML(args.input_html, base_url=args.base_url).write_pdf(args.output_pdf)
    print(f"PDF geschrieben -> {args.output_pdf}")


if __name__ == "__main__":
    main()
