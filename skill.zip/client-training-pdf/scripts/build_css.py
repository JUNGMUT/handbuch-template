#!/usr/bin/env python3
"""
Setzt design-tokens.json in style_base.css ein und legt die finale style.css
im Output-Verzeichnis ab.

Nutzung:
    python3 build_css.py <design_tokens.json> <output_dir> [--template <style_base.css>]

Erwartet design-tokens.json im Format wie in
client-training-content/f4t/design-tokens.json vorgemacht (siehe README dort).
"""
import argparse, json, os, sys

DEFAULT_TEMPLATE = os.path.join(os.path.dirname(__file__), "style_base.css")

TOKEN_KEYS = {
    "PRIMARY": ("colors", "primary"),
    "PRIMARY_MEDIUM": ("colors", "primary_medium"),
    "PRIMARY_LIGHT": ("colors", "primary_light"),
    "SECONDARY": ("colors", "secondary"),
    "SECONDARY_MEDIUM": ("colors", "secondary_medium"),
    "SECONDARY_LIGHT": ("colors", "secondary_light"),
    "SECONDARY_LIGHT2": ("colors", "secondary_light2"),
    "TERTIARY1": ("colors", "tertiary1"),
    "TERTIARY1_MEDIUM": ("colors", "tertiary1_medium"),
    "TERTIARY1_LIGHT": ("colors", "tertiary1_light"),
    "TERTIARY1_LIGHT2": ("colors", "tertiary1_light2"),
    "TERTIARY2": ("colors", "tertiary2"),
    "TERTIARY2_MEDIUM": ("colors", "tertiary2_medium"),
    "TERTIARY2_LIGHT": ("colors", "tertiary2_light"),
    "BLACK": ("colors", "black"),
    "WHITE": ("colors", "white"),
    "GREY": ("colors", "grey"),
    "LIGHTGREY": ("colors", "lightgrey"),
    "ERROR": ("colors", "error"),
    "RADIUS_SM": ("radius", "sm"),
    "RADIUS_MD": ("radius", "md"),
    "RADIUS_LG": ("radius", "lg"),
    "SHADOW": (None, "shadow"),
    "CLIENT_NAME": (None, "client_name"),
}

# Sinnvolle Fallbacks, falls ein Kunde ein Token mal nicht liefert.
FALLBACKS = {
    "RADIUS_SM": "12px", "RADIUS_MD": "20px", "RADIUS_LG": "32px",
    "SHADOW": "0 1px 8px 4px rgba(0,0,0,0.06)",
    "CLIENT_NAME": "Website-Schulung",
}


def get_token(tokens: dict, key: str) -> str:
    group, field = TOKEN_KEYS[key]
    if group and group in tokens and field in tokens[group]:
        return tokens[group][field]
    if not group and field in tokens:
        return tokens[field]
    if key in FALLBACKS:
        return FALLBACKS[key]
    raise KeyError(f"Token '{key}' fehlt in design-tokens.json und hat keinen Fallback.")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("tokens_json")
    ap.add_argument("output_dir")
    ap.add_argument("--template", default=DEFAULT_TEMPLATE)
    args = ap.parse_args()

    with open(args.tokens_json, encoding="utf-8") as f:
        tokens = json.load(f)

    with open(args.template, encoding="utf-8") as f:
        css = f.read()

    for key in TOKEN_KEYS:
        placeholder = "{{" + key + "}}"
        if placeholder in css:
            css = css.replace(placeholder, str(get_token(tokens, key)))

    os.makedirs(args.output_dir, exist_ok=True)
    out_path = os.path.join(args.output_dir, "style.css")
    with open(out_path, "w", encoding="utf-8") as f:
        f.write(css)
    print(f"style.css geschrieben -> {out_path}")


if __name__ == "__main__":
    main()
