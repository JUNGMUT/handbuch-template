#!/usr/bin/env python3
"""
Legt im Build-Ordner das feste JUNGMUT-Design ab:
    <build_dir>/style.css                 (Kopie von scripts/jungmut.css)
    <build_dir>/assets/fonts/heading.ttf  (Unbounded)
    <build_dir>/assets/fonts/body.ttf     (Nunito Sans)

Nutzung:
    python3 setup_build.py <build_dir>

Das Design ist bewusst NICHT konfigurierbar — alle Handbücher laufen im
JUNGMUT-Design, passend zur basic.pdf. Farben/Schriften nur in
scripts/jungmut.css ändern (und dann auch die basic.pdf neu bauen).
"""
import os
import shutil
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
FONTS = os.path.join(HERE, "..", "assets", "fonts")


def main():
    if len(sys.argv) != 2:
        sys.exit(__doc__)
    build = sys.argv[1]
    os.makedirs(os.path.join(build, "assets", "fonts"), exist_ok=True)
    shutil.copy(os.path.join(HERE, "jungmut.css"), os.path.join(build, "style.css"))
    shutil.copy(os.path.join(FONTS, "Unbounded-Variable.ttf"),
                os.path.join(build, "assets", "fonts", "heading.ttf"))
    shutil.copy(os.path.join(FONTS, "NunitoSans-Variable.ttf"),
                os.path.join(build, "assets", "fonts", "body.ttf"))
    print(f"JUNGMUT-Design bereit -> {build}/style.css + assets/fonts/")


if __name__ == "__main__":
    main()
