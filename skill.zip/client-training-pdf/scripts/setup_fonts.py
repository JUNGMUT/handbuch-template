#!/usr/bin/env python3
"""
Stellt assets/fonts/heading.ttf + body.ttf für den Output bereit.

Bekannte, im Skill mitgelieferte Fonts (siehe skill_root/assets/fonts/):
  - "Sora"  -> Sora-Variable.ttf   (auf Google Fonts frei, meist 1:1 nutzbar)
  - "Inter" -> Inter-Variable.ttf  (gute freie Alternative zu vielen
                                     proprietären Grotesk-Schriften wie
                                     Aptos, Söhne, Circular etc.)

Für einen neuen Kunden: in design-tokens.json unter fonts.heading.use_as /
fonts.body.use_as einen der obigen Namen eintragen, ODER selbst eine .ttf in
den Kundenordner legen und deren Pfad direkt angeben (siehe --heading-file /
--body-file).

Nutzung:
    python3 setup_fonts.py <design_tokens.json> <output_assets_dir>
        [--heading-file <pfad.ttf>] [--body-file <pfad.ttf>]
"""
import argparse, json, os, shutil, sys

SKILL_FONTS = os.path.join(os.path.dirname(__file__), "..", "assets", "fonts")
KNOWN = {
    "sora": "Sora-Variable.ttf",
    "inter": "Inter-Variable.ttf",
    "unbounded": "Unbounded-Variable.ttf",
    "nunito sans": "NunitoSans-Variable.ttf",
    "nunitosans": "NunitoSans-Variable.ttf",
}


def resolve(name: str) -> str:
    key = (name or "").strip().lower()
    if key in KNOWN:
        path = os.path.join(SKILL_FONTS, KNOWN[key])
        if os.path.exists(path):
            return path
    raise FileNotFoundError(
        f"Font '{name}' ist nicht als Skill-Asset vorhanden. Bekannt: {list(KNOWN)}. "
        f"Nutze --heading-file/--body-file, um eine eigene .ttf-Datei anzugeben."
    )


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("tokens_json")
    ap.add_argument("output_assets_dir")
    ap.add_argument("--heading-file", default=None)
    ap.add_argument("--body-file", default=None)
    args = ap.parse_args()

    with open(args.tokens_json, encoding="utf-8") as f:
        tokens = json.load(f)

    fonts_out = os.path.join(args.output_assets_dir, "fonts")
    os.makedirs(fonts_out, exist_ok=True)

    heading_src = args.heading_file or resolve(tokens.get("fonts", {}).get("heading", {}).get("use_as", "Sora"))
    body_src = args.body_file or resolve(tokens.get("fonts", {}).get("body", {}).get("use_as", "Inter"))

    shutil.copy(heading_src, os.path.join(fonts_out, "heading.ttf"))
    shutil.copy(body_src, os.path.join(fonts_out, "body.ttf"))
    print(f"Fonts bereit: heading <- {heading_src}")
    print(f"              body    <- {body_src}")


if __name__ == "__main__":
    main()
