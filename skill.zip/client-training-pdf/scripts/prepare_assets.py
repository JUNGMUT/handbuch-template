#!/usr/bin/env python3
"""
Bereitet die Screenshots eines Kundenprojekts fürs PDF-Rendering vor.

Nutzung:
    python3 prepare_assets.py <screenshots_root> <output_assets_dir> [--max-dim 1600]

- Kopiert alle Bilder (png/jpg/jpeg) rekursiv aus <screenshots_root> nach
  <output_assets_dir>, mit sicheren Dateinamen (Unterordner werden mit "__"
  ins Präfix codiert, damit Referenzen wie "elementor/foo.png" eindeutig
  bleiben).
- Skaliert Bilder, deren längste Kante > max-dim ist, herunter (Standard
  1600px) und optimiert die PNG-Kompression — hält die PDF-Dateigröße im
  Rahmen (Faktor ~2x kleiner ist üblich).
- Schreibt image_map.json: {original_relpath: {safe, w, h}}
  Dieses Mapping wird von helpers.py::img() genutzt, um Bilder einzubetten
  und automatisch zu klassifizieren (schmal / mittel / volle Breite).
"""
import argparse, json, os, re, shutil, sys
from PIL import Image


def safe_name(rel_dir: str, filename: str) -> str:
    safe = re.sub(r'[^a-zA-Z0-9._-]', '-', filename)
    safe = re.sub(r'-+', '-', safe)
    return f"{rel_dir}__{safe}" if rel_dir not in ('', '.') else safe


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("screenshots_root")
    ap.add_argument("output_assets_dir")
    ap.add_argument("--max-dim", type=int, default=1600)
    ap.add_argument("--map-out", default=None, help="Pfad für image_map.json (Default: neben output_assets_dir)")
    args = ap.parse_args()

    os.makedirs(args.output_assets_dir, exist_ok=True)
    mapping = {}

    for dirpath, _, filenames in os.walk(args.screenshots_root):
        for fn in sorted(filenames):
            if fn.startswith('.') or not fn.lower().endswith(('.png', '.jpg', '.jpeg')):
                continue
            full = os.path.join(dirpath, fn)
            rel_dir = os.path.relpath(dirpath, args.screenshots_root)
            out_name = safe_name(rel_dir, fn)
            out_path = os.path.join(args.output_assets_dir, out_name)

            im = Image.open(full)
            w, h = im.size
            max_side = max(w, h)
            if max_side > args.max_dim:
                scale = args.max_dim / max_side
                im = im.convert("RGB") if im.mode in ("P",) else im
                im = im.resize((int(w * scale), int(h * scale)), Image.LANCZOS)
                w, h = im.size
            im.save(out_path, optimize=True)

            rel_key = os.path.join(rel_dir, fn) if rel_dir not in ('', '.') else fn
            mapping[rel_key] = {"safe": out_name, "w": w, "h": h}

    map_out = args.map_out or os.path.join(os.path.dirname(args.output_assets_dir.rstrip('/')), "image_map.json")
    with open(map_out, "w", encoding="utf-8") as f:
        json.dump(mapping, f, indent=2, ensure_ascii=False)

    print(f"{len(mapping)} Bilder verarbeitet -> {args.output_assets_dir}")
    print(f"image_map.json geschrieben -> {map_out}")


if __name__ == "__main__":
    main()
