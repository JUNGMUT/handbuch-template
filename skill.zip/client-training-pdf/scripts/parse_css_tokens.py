#!/usr/bin/env python3
"""
Analysiert bereits heruntergeladene CSS-Dateien (siehe SKILL.md Schritt 0)
und gibt einen Kandidaten-Report für design-tokens.json aus.

Läuft komplett OFFLINE — lädt selbst nichts aus dem Netz. Die CSS-Dateien
müssen vorher per web_fetch (oder curl, falls die Domain im Netzwerk-
Allowlist steht) besorgt und lokal gespeichert worden sein.

Nutzung:
    python3 parse_css_tokens.py <css_datei_1> [<css_datei_2> ...] [--out report.json]
"""
import argparse, json, re, sys
from collections import Counter

HEX_RE = re.compile(r'#(?:[0-9a-fA-F]{6}|[0-9a-fA-F]{3})\b')
FONT_FACE_FAMILY_RE = re.compile(r'@font-face\s*{[^}]*font-family\s*:\s*[\'"]([^\'"]+)[\'"]', re.IGNORECASE | re.DOTALL)
RADIUS_RE = re.compile(r'border-radius\s*:\s*(\d+(?:\.\d+)?)(px|rem|em)', re.IGNORECASE)
SHADOW_RE = re.compile(r'box-shadow\s*:\s*([^;{}]+)', re.IGNORECASE)

# Grobe Heuristik: welche Selektoren typischerweise die Heading- bzw.
# Body-Schrift setzen. Deckt keine komplexe CSS-Kaskade ab — dient nur als
# Startpunkt, den Claude/du anschließend gegenlest.
HEADING_SELECTOR_RE = re.compile(
    r'(?:^|[}\s])(?:h1|h2|h3|h4|h5|h6|\.h1|\.h2|\.h3)[^{]*\{[^}]*font-family\s*:\s*[\'"]?([^;\'"}]+)',
    re.IGNORECASE
)
BODY_SELECTOR_RE = re.compile(
    r'(?:^|[}\s])body\s*\{[^}]*font-family\s*:\s*[\'"]?([^;\'"}]+)',
    re.IGNORECASE
)

# Farben, die praktisch immer neutral sind (Text/Hintergrund) und daher
# nicht automatisch als "primary/tertiary" vorgeschlagen werden sollten.
NEUTRAL_GUESS = {"#fff", "#ffffff", "#000", "#000000"}


def analyze(paths):
    text = ""
    for p in paths:
        with open(p, encoding="utf-8", errors="ignore") as f:
            text += f.read() + "\n"

    colors = Counter(m.group(0).lower() for m in HEX_RE.finditer(text))
    font_faces = sorted(set(FONT_FACE_FAMILY_RE.findall(text)))
    heading_candidates = [m.strip().strip("!important").strip() for m in HEADING_SELECTOR_RE.findall(text)]
    body_candidates = [m.strip().strip("!important").strip() for m in BODY_SELECTOR_RE.findall(text)]
    radii = Counter(f"{m[0]}{m[1]}" for m in RADIUS_RE.findall(text))
    shadows = list(dict.fromkeys(s.strip() for s in SHADOW_RE.findall(text)))[:8]

    likely_brand_colors = [
        {"hex": h, "count": c} for h, c in colors.most_common(30) if h not in NEUTRAL_GUESS
    ]

    return {
        "top_colors_all": [{"hex": h, "count": c} for h, c in colors.most_common(20)],
        "likely_brand_colors": likely_brand_colors[:12],
        "font_faces_declared": font_faces,
        "heading_font_candidates": sorted(set(heading_candidates))[:5],
        "body_font_candidates": sorted(set(body_candidates))[:5],
        "border_radius_frequency": [{"value": v, "count": c} for v, c in radii.most_common(8)],
        "box_shadow_samples": shadows,
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("css_files", nargs="+")
    ap.add_argument("--out", default=None)
    args = ap.parse_args()

    report = analyze(args.css_files)
    out = json.dumps(report, indent=2, ensure_ascii=False)

    if args.out:
        with open(args.out, "w", encoding="utf-8") as f:
            f.write(out)
        print(f"Report geschrieben -> {args.out}")
    else:
        print(out)


if __name__ == "__main__":
    main()
