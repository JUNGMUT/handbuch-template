# -*- coding: utf-8 -*-
"""
Wird von jedem Kunden-Build importiert (siehe SKILL.md, Schritt 4).

Verwendung im Content-Skript des Kunden:

    from helpers import load_images, img

    IMAGES, CAPTIONS = load_images("image_map.json", "captions.json")
    html_snippet = img("elementor/blank-page-overview.png", IMAGES, CAPTIONS)

captions.json ist optional (Claude schreibt es pro Kunde von Hand, siehe
SKILL.md) — fehlt ein Eintrag, wird eine lesbare Caption automatisch aus dem
Dateinamen abgeleitet (Bindestriche -> Leerzeichen, capitalized).
"""
import json
import os
import re


def load_images(image_map_path: str, captions_path: str | None = None):
    with open(image_map_path, encoding="utf-8") as f:
        images = json.load(f)
    captions = {}
    if captions_path and os.path.exists(captions_path):
        with open(captions_path, encoding="utf-8") as f:
            captions = json.load(f)
    return images, captions


def _fallback_caption(original_key: str) -> str:
    base = os.path.splitext(os.path.basename(original_key))[0]
    base = re.sub(r'[-_]+', ' ', base).strip()
    return base[:1].upper() + base[1:] if base else ""


def classify(w: int, h: int) -> str:
    """Klassifiziert ein Bild anhand des Seitenverhältnisses.
    < 0.9  -> schmal (Sidebar-/Popup-Crops, hochkant)
    < 1.3  -> mittel (quadratisch / leicht breiter)
    sonst  -> volle Breite (Screenshots, Banner)
    """
    ratio = w / h if h else 1
    if ratio < 0.9:
        return "img-narrow"
    if ratio < 1.3:
        return "img-medium"
    return "img-full"


def img(key: str, images: dict, captions: dict, override_class: str | None = None) -> str:
    """Erzeugt einen <figure>-Block für ein Bild aus image_map.json.

    key = der ORIGINALE relative Pfad, wie er in der index.md referenziert
    wird (z.B. "elementor/blank-page-overview.png") — NICHT der safe name.
    """
    if key not in images:
        raise KeyError(
            f"Bild-Referenz '{key}' nicht in image_map.json gefunden. "
            f"Lief prepare_assets.py über den richtigen screenshots_root?"
        )
    data = images[key]
    safe, w, h = data["safe"], data["w"], data["h"]
    cls = override_class or classify(w, h)
    caption = captions.get(safe) or captions.get(key) or _fallback_caption(key)
    cap_html = f"<figcaption>{caption}</figcaption>" if caption else ""
    alt = caption.replace('"', "'")
    return (
        f'<figure class="{cls}">\n'
        f'  <img src="assets/{safe}" alt="{alt}">\n'
        f'  {cap_html}\n'
        f'</figure>'
    )


def img_row(*html_blocks: str) -> str:
    """Zwei (oder mehr) Bilder nebeneinander (z. B. zwei Sidebar-Screenshots)."""
    inner = "\n".join(html_blocks)
    return f'<div class="img-row">\n{inner}\n</div>'
