# -*- coding: utf-8 -*-
"""
Wird von jedem Kunden-Build (build_content.py) importiert, siehe SKILL.md.

Verwendung im Content-Skript des Kunden:

    from helpers import load_images, img

    IMAGES, CAPTIONS = load_images("image_map.json", "captions.json")
    html_snippet = img("elementor/blank-page-overview.png", IMAGES, CAPTIONS)

captions.json ist optional (Claude schreibt es pro Kunde von Hand, siehe
SKILL.md) — fehlt ein Eintrag, wird eine lesbare Caption automatisch aus dem
Dateinamen abgeleitet (Bindestriche -> Leerzeichen, capitalized).
"""
import json
import os
import re


def load_images(image_map_path: str, captions_path: str | None = None):
    with open(image_map_path, encoding="utf-8") as f:
        images = json.load(f)
    captions = {}
    if captions_path and os.path.exists(captions_path):
        with open(captions_path, encoding="utf-8") as f:
            captions = json.load(f)
    return images, captions


def _fallback_caption(original_key: str) -> str:
    base = os.path.splitext(os.path.basename(original_key))[0]
    base = re.sub(r'[-_]+', ' ', base).strip()
    return base[:1].upper() + base[1:] if base else ""


def classify(w: int, h: int) -> str:
    """Klassifiziert ein Bild anhand des Seitenverhältnisses.
    < 0.9  -> schmal (Sidebar-/Popup-Crops, hochkant)
    < 1.3  -> mittel (quadratisch / leicht breiter)
    sonst  -> volle Breite (Screenshots, Banner)
    """
    ratio = w / h if h else 1
    if ratio < 0.9:
        return "img-narrow"
    if ratio < 1.3:
        return "img-medium"
    return "img-full"


def img(key: str, images: dict, captions: dict, override_class: str | None = None) -> str:
    """Erzeugt einen <figure>-Block für ein Bild aus image_map.json.

    key = der ORIGINALE relative Pfad, wie er in der index.md referenziert
    wird (z.B. "elementor/blank-page-overview.png") — NICHT der safe name.
    """
    if key not in images:
        raise KeyError(
            f"Bild-Referenz '{key}' nicht in image_map.json gefunden. "
            f"Lief prepare_assets.py über den richtigen screenshots_root?"
        )
    data = images[key]
    safe, w, h = data["safe"], data["w"], data["h"]
    cls = override_class or classify(w, h)
    caption = captions.get(safe) or captions.get(key) or _fallback_caption(key)
    cap_html = f"<figcaption>{caption}</figcaption>" if caption else ""
    alt = caption.replace('"', "'")
    return (
        f'<figure class="{cls}">\n'
        f'  <img src="assets/{safe}" alt="{alt}">\n'
        f'  {cap_html}\n'
        f'</figure>'
    )


def img_row(*html_blocks: str) -> str:
    """Zwei (oder mehr) Bilder nebeneinander (z. B. zwei Sidebar-Screenshots)."""
    inner = "\n".join(html_blocks)
    return f'<div class="img-row">\n{inner}\n</div>'


WIDTH_HINTS = {"schmal": "img-narrow", "mittel": "img-medium", "voll": "img-full"}


def width_class(hint: str | None) -> str | None:
    """Übersetzt den customer.md-Hinweis {schmal|mittel|voll} in die CSS-Klasse."""
    return WIDTH_HINTS.get((hint or "").strip().lower()) if hint else None


def chapter(num: str, title: str, body_html: str) -> str:
    """Ein Kapitel (oder Unterkapitel wie "10.1") – beginnt immer auf neuer Seite
    und landet automatisch im Inhaltsverzeichnis (assemble.py liest die h1)."""
    return (f'<section class="chapter">\n'
            f'<h1 class="chapter-title"><span class="chapter-num">{num}</span>{title}</h1>\n'
            f'{body_html}\n</section>')


def callout(kind: str, body_html: str, title: str | None = None) -> str:
    """kind: "info" (Gut zu wissen, grün) | "warning" (Wichtig, blau) | "tip" (Tipp, lila)."""
    cls = {"info": "callout", "warning": "callout warning", "tip": "callout tip"}[kind]
    default = {"info": "Gut zu wissen", "warning": "Wichtig", "tip": "Tipp"}[kind]
    return (f'<div class="{cls}"><span class="callout-title">{title or default}</span>'
            f'{body_html}</div>')


def fieldbox(title: str, rows: list, legend: bool = True) -> str:
    """rows: [(feldname, beschreibung, pflicht: bool), ...]"""
    req_attr = ' class="required"'
    trs = "\n".join(
        f'<tr{req_attr if req else ""}><td class="k">{k}</td><td>{v}</td></tr>'
        for k, v, req in rows)
    leg = ('<p class="legend">* Pflichtfelder sind mit einem Sternchen markiert.</p>'
           if legend and any(r[2] for r in rows) else "")
    return (f'<div class="fieldbox"><span class="fieldbox-title">{title}</span>'
            f'<table class="fields">\n{trs}\n</table>{leg}</div>')


def document(chapters_html: str, title: str = "Kunden-Ergänzungen") -> str:
    """Komplettes content.html-Gerüst (nur Kunden-Kapitel, KEIN Cover/TOC –
    die kommen aus basic.pdf bzw. assemble.py)."""
    return ('<!DOCTYPE html>\n<html lang="de"><head><meta charset="utf-8">'
            f'<title>{title}</title><link rel="stylesheet" href="style.css"></head>\n'
            f'<body>\n{chapters_html}\n</body></html>')
