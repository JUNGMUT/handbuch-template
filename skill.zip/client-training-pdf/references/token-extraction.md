# Design-Tokens aus Website oder Figma ableiten

Zwei Quellen sind möglich. Beide münden im selben Ziel: eine vollständig
ausgefüllte `design-tokens.json` nach dem Schema aus `f4t/design-tokens.json`.

## Quelle A: Website-Link

1. **Homepage laden**, um die verlinkten Stylesheets zu finden:
   `web_fetch(<homepage-url>)` — liefert i. d. R. nur Text, aber falls die
   Domain im Netzwerk-Allowlist des Containers steht (prüfen!), kann
   stattdessen `curl <url>` im bash-Tool das rohe HTML liefern, was die
   `<link rel="stylesheet">`-Tags sichtbar macht (`grep stylesheet`).
   Ist die Domain NICHT im Allowlist: die CSS-Dateien einzeln per
   `web_fetch` laden (funktioniert unabhängig vom Container-Netzwerk) und
   den Inhalt mit `create_file` lokal ablegen.
2. Priorität bei vielen Stylesheets: das **Theme-eigene CSS** (meist
   `wp-content/themes/<theme>/...`) und ein **Fonts-CSS** — Plugin-CSS
   (WPForms, SEO-Plugins etc.) ignorieren, das sind keine Marken-Tokens.
3. Lokal gespeicherte CSS-Dateien analysieren:
   ```bash
   python3 <skill_root>/scripts/parse_css_tokens.py \
       pfad/zu/style.css pfad/zu/fonts.css --out report.json
   ```
4. Report interpretieren (siehe Mapping-Regeln unten) und
   `design-tokens.json` von Hand daraus befüllen.

## Quelle B: Figma-Link

1. Prüfen, ob der Figma Dev-Mode-MCP-Server verbunden ist (Tool
   `get_variable_defs` testen). Falls nicht: Nutzer bitten, in der Figma
   Desktop-App unter Preferences → "Enable Dev Mode MCP Server" zu
   aktivieren und die Datei/den Node offen zu haben (siehe ggf. frühere
   Chat-Historie für genaue Fehlermeldungen/Troubleshooting).
2. `get_variable_defs(nodeId=...)` liefert benannte Farb-/Typografie-
   Variablen direkt — i. d. R. schon mit sprechenden Namen (z. B.
   "primary/medium"), das Mapping ist damit oft eindeutiger als bei
   Quelle A.
3. Falls Farben ohne Variablen-Namen vorliegen (nur Hex-Werte an Layern):
   `get_design_context` bzw. `get_screenshot` für den Styleguide-Frame
   nutzen und die Werte visuell/aus dem generierten Code ablesen.

## Mapping-Regeln (Report → design-tokens.json)

- **`primary`**: die dominanteste NICHT-neutrale Farbe (also nicht
  Schwarz/Weiß/Grau) aus `likely_brand_colors` — meist die Farbe von
  Buttons/Links/Hover-States. Bei Unsicherheit: die Farbe, die am meisten
  in Kombination mit `button`, `link`, `cta`, `hover` im CSS-Kontext
  auftaucht.
- **`primary_medium` / `primary_light`**: hellere/dunklere Varianten
  derselben Farbfamilie aus den nächsten Treffern in `likely_brand_colors`
  (ähnlicher Hue). Fehlen passende Varianten: `primary` selbst mit
  reduzierter Deckkraft-Optik nachbilden (z. B. per Colorpicker manuell
  aufhellen) — NICHT einfach Schwarz/Weiß mischen ohne Rücksprache.
- **`secondary`**: die dominante neutrale Dunkelfarbe (meist Text- oder
  Hintergrundfarbe, oft `#000`-nah oder ein dunkles Blaugrau).
- **`secondary_medium/light/light2`**: aus den übrigen Grau-/Neutraltönen
  im Report ableiten, absteigend nach Helligkeit sortiert.
- **`tertiary1` / `tertiary2`**: die übrigen, klar unterscheidbaren
  Akzentfarben (Pastelltöne, Zweitfarben) — meist 1-2 pro Marke erkennbar
  an mehreren zusammengehörigen Varianten (z. B. drei Lila-Töne).
- **Fonts**: `heading_font_candidates` = Schrift für Überschriften,
  `body_font_candidates` = Fließtext. Bei Unsicherheit den tatsächlichen
  `body{font-family:...}`-Treffer bevorzugen (zuverlässiger als
  Utility-Klassen). Prüfen, ob der Font-Name in
  `scripts/setup_fonts.py::KNOWN` bereits als Skill-Asset existiert
  (aktuell: Sora, Inter, Unbounded, Nunito Sans). Falls nicht: auf Google
  Fonts prüfen (meist per `raw.githubusercontent.com/google/fonts/...`
  ladbar, siehe `setup_fonts.py`-Kommentar für die URL-Struktur) und als
  neuen Eintrag in `KNOWN` + `assets/fonts/` ergänzen — der Skill wächst so
  mit jedem neuen Kunden mit. Ist die Schrift proprietär/lizenziert: eine
  optisch ähnliche freie Alternative wählen und das im Chat transparent
  machen (siehe f4t/-Beispiel: Aptos → Inter).
- **`radius`**: häufigster `border-radius`-Wert aus dem Report als `lg`,
  kleinere Werte als `sm`/`md` gruppieren.
- **`shadow`**: einen dezenten, repräsentativen `box-shadow`-Wert aus den
  Samples wählen (keine `inset`-Schatten, keine `!important`-Anhänge
  übernehmen).

Bei jeder Unsicherheit in der Zuordnung: kurz im Chat nachfragen statt zu
raten, besonders bei `primary` (das ist die Farbe, die im PDF am meisten
auffällt — falsch gewählt, wirkt das ganze Dokument "off-brand").
