# HTML-Bausteine & Helper für die Kunden-Kapitel

Alle Klassen kommen aus `style.css` (= `scripts/jungmut.css`, von
`setup_build.py` in den Build-Ordner kopiert). Cover und Inhaltsverzeichnis
baust du NICHT – die kommen aus basic.pdf bzw. `assemble.py`.

## Grundgerüst von build_content.py

```python
import os, sys
sys.path.insert(0, "<skill>/scripts")
from helpers import (load_images, img, img_row, chapter, callout,
                     fieldbox, document, width_class)

HERE = os.path.dirname(os.path.abspath(__file__))
IMAGES, CAPTIONS = load_images(os.path.join(HERE, "image_map.json"),
                               os.path.join(HERE, "captions.json"))

c10 = chapter("10", "Veranstaltungen verwalten", f"""
<p>…</p>
{img("veranstaltungen/uebersicht.png", IMAGES, CAPTIONS)}
<h2>Neue Veranstaltung anlegen</h2>
<ul class="check"><li>…</li></ul>
""")
c101 = chapter("10.1", "Veranstaltungen importieren", "…")   # Unterkapitel ({toc})

with open(os.path.join(HERE, "content.html"), "w", encoding="utf-8") as f:
    f.write(document(c10 + c101))
```

`chapter()` erzeugt
```html
<section class="chapter">
<h1 class="chapter-title"><span class="chapter-num">10</span>Titel</h1>
…
</section>
```
Jedes Kapitel startet auf einer neuen Seite. `assemble.py` liest genau diese
`h1.chapter-title` fürs Inhaltsverzeichnis und die Lesezeichen — also keine
weiteren `<h1>` im Fließtext verwenden (Zwischenüberschriften = `<h2>`/`<h3>`).

## Callouts

```python
callout("info", "Text …")              # Gut zu wissen – grün
callout("warning", "Text …")           # Wichtig – blau
callout("tip", "Text …")               # Tipp – lila
callout("tip", "Text …", title="Im Zweifel")   # eigener Titel
```

## Feldbox

```python
fieldbox("Felder einer Veranstaltung", [
    ("Titel", "Name der Veranstaltung", True),     # True = Pflichtfeld (*)
    ("Ort", "Freitext", False),
])
```

## Checkliste / Schritte

```html
<ul class="check">
  <li><strong>Stichwort:</strong> Erklärung.</li>
</ul>
```
Nummerierte Abfolge alternativ als `<ol>` (Nummern in JM-Blau).

## Do's-and-Don'ts-Tabelle

```html
<table class="dosdonts">
<tr><th>Bereich</th><th>Do</th><th>Don't</th></tr>
<tr>
  <td>Bereichsname</td>
  <td><span class="badge badge-do">Do</span>Gutes Verhalten</td>
  <td><span class="badge badge-dont">Don't</span>Zu vermeiden</td>
</tr>
</table>
```
NIE Emoji (✅/❌) – werden nicht gerendert.

## Bilder

Immer über `img()` einbinden, nie `<img>` von Hand:

```python
img("veranstaltungen/uebersicht.png", IMAGES, CAPTIONS)                       # Breite automatisch
img("menue/sidebar.png", IMAGES, CAPTIONS, override_class="img-narrow")       # erzwingen
img("menue/sidebar.png", IMAGES, CAPTIONS, width_class("schmal"))             # aus {schmal} in customer.md
img_row(img("a.png", IMAGES, CAPTIONS, "img-full"),
        img("b.png", IMAGES, CAPTIONS, "img-full"))                           # nebeneinander
```
- `img-narrow` — hochkante Sidebar-/Popup-Crops
- `img-medium` — quadratische/kleine UI-Ausschnitte
- `img-full` — ganze Screenshots, breite Banner

## Sonstiges

- `<span class="step-num">1</span>` — runde Schritt-Nummer in JM-Blau
- `<code>` — für URLs/Shortcodes im Fließtext
