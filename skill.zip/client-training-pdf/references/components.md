# HTML-Bausteine für den Content-Build

Diese Snippets in dein Kapitel-HTML einbauen (siehe SKILL.md Schritt 4).
Alle CSS-Klassen kommen aus `style.css` (generiert aus `style_base.css`).

## Cover

```html
<div class="cover">
  <div class="blob"></div>
  <div>
    <div class="eyebrow">Website-Schulung</div>
    <h1>{{ Haupttitel, 2 Zeilen max }}</h1>
    <div class="subtitle">{{ 1-2 Sätze Untertitel }}</div>
  </div>
  <div class="footer-block">
    <span>{{ Kundenname }}</span>
    <span>Schulungsunterlage</span>
  </div>
</div>
```

## Inhaltsverzeichnis

```html
<div class="toc-page">
  <h1>Inhalt</h1>
  <ul class="toc-list">
    <li><span class="num">1</span><span class="label">Kapitelname</span></li>
    ...
  </ul>
</div>
```

## Kapitel-Grundgerüst

```html
<section class="chapter">
<h1 class="chapter-title"><span class="chapter-num">1</span>Kapitelname</h1>
<p>Fließtext...</p>
<h2>Zwischenüberschrift</h2>
<p>...</p>
</section>
```
Jedes `<section class="chapter">` beginnt automatisch auf einer neuen Seite
(`break-before: page` in der CSS). Kein manuelles `<div style="page-break">`
nötig.

## Callout-Box (drei Varianten)

```html
<div class="callout">                 <!-- neutral / blau -->
  <span class="callout-title">Gut zu wissen</span>
  Text...
</div>

<div class="callout warning">         <!-- gelb, für "Wichtig"/Warnungen -->
  <span class="callout-title">Wichtig</span>
  Text...
</div>

<div class="callout tip">             <!-- hellblau, für Tipps -->
  <span class="callout-title">Tipp</span>
  Text...
</div>
```

## Feld-/Spezifikationsbox (z. B. für Custom-Post-Type-Felder)

Pflichtfelder bekommen `class="required"` auf dem `<tr>` — die CSS setzt
automatisch ein rotes Sternchen ans Feldlabel.

```html
<div class="fieldbox">
<span class="fieldbox-title">Felder im Überblick</span>
<table class="fields">
<tr class="required"><td class="k">Feldname</td><td>Beschreibung, was es tut.</td></tr>
<tr><td class="k">Optionales Feld</td><td>Beschreibung.</td></tr>
</table>
<p class="legend">* Pflichtfelder sind mit einem Sternchen markiert.</p>
</div>
```

## Checkliste (statt normalem `<ul>`)

```html
<ul class="check">
  <li><strong>Stichwort:</strong> Erklärung.</li>
</ul>
```

## Do's-and-Don'ts-Tabelle

```html
<table class="dosdonts">
<tr><th>Bereich</th><th>Do</th><th>Don't</th></tr>
<tr>
  <td>Bereichsname</td>
  <td><span class="badge badge-do">Do</span>Beschreibung des guten Verhaltens</td>
  <td><span class="badge badge-dont">Don't</span>Beschreibung des zu vermeidenden Verhaltens</td>
</tr>
</table>
```
NIE Emoji (✅/❌) verwenden — WeasyPrint/die Fonts rendern die meisten Emoji
nicht. Immer die `.badge`-Klassen nutzen.

## Bilder

Über `helpers.py::img()` einbinden, NIE `<img>` von Hand schreiben (sonst
fehlt die automatische Klassifizierung/Caption-Logik):

```python
from helpers import load_images, img, img_row
IMAGES, CAPTIONS = load_images("image_map.json", "captions.json")

# einzelnes Bild, automatische Breiten-Klasse:
img("elementor/blank-page-overview.png", IMAGES, CAPTIONS)

# einzelnes Bild, Breite manuell erzwingen (img-narrow / img-medium / img-full):
img("dashboard/wp-admin-url.png", IMAGES, CAPTIONS, override_class="img-medium")

# zwei Bilder nebeneinander (z. B. zwei schmale Sidebar-Screenshots):
img_row(
    img("elementor/widgets-sidebar-basics.png", IMAGES, CAPTIONS, "img-full"),
    img("elementor/widgets-sidebar-custom-widgets.png", IMAGES, CAPTIONS, "img-full"),
)
```

Faustregel für `override_class`, falls die Auto-Klassifizierung mal nicht
passt:
- `img-narrow` — schmale Sidebar-/Popup-Crops (hochkant)
- `img-medium` — quadratische oder kleine UI-Ausschnitte
- `img-full` — vollständige Screenshots, breite Banner

## Zwei Bilder nebeneinander ohne `img_row`-Helper

Falls `img_row()` nicht passt (z. B. drei Bilder), das Markup direkt schreiben:

```html
<div class="img-row">
  {{ figure 1 }}
  {{ figure 2 }}
</div>
```
