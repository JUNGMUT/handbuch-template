# Konventionen für index.md (Kunden-Briefing)

Jedes Kundenprojekt hat eine `index.md`, in der die Person, die das
Schulungsmaterial in Auftrag gibt, stichpunktartig vorgibt, was beschrieben
werden soll. Diese Datei ist KEIN fertiger Text — sie ist ein Briefing, das
du (Claude) zu vollständigen, ausformulierten Kapiteln ausbaust.

## Das `AUSBAU:`-Prefix

Zeilen, die mit `AUSBAU:` (oder `AUSBAU (kurz):` / `AUSBAU (ausführlich):`)
beginnen, sind Stichpunkte, die du zu vollständigen Absätzen ausbaust —
NICHT wörtlich übernehmen. Der Klammerzusatz `(kurz)` / `(ausführlich)`
steuert, wie viel Tiefe/Umfang der ausgebaute Abschnitt bekommen soll.

Beispiel Input:
```
AUSBAU: Elementor Widget "Bild" – Position, Größe und Ausrichtung erklären
```

Wird zu einem vollständigen Absatz mit Kontext, ggf. Liste, ggf.
Callout-Box — nicht nur ein umformulierter Satz.

Text OHNE `AUSBAU:`-Prefix ist bereits vom Kunden/Auftraggeber final
formuliert oder als Fakt zu behandeln (z. B. konkrete Feldnamen, Pflicht-
/Optional-Status) — hier nicht frei erfinden, sondern exakt übernehmen bzw.
nur sprachlich glätten.

## Bild-Referenzen

Bilder werden in der `index.md` per relativem Pfad referenziert (z. B.
`references/elementor/blank-page-overview.png` oder nur als Erwähnung im
Fließtext). Der tatsächliche `key`, den du an `helpers.py::img()` übergibst,
ist der Pfad **relativ zum `screenshots/`-Ordner**, OHNE führendes
`references/` (das war nur der Ordnername im Original-Zip) — z. B.
`elementor/blank-page-overview.png`.

Prüfe IMMER gegen `image_map.json` (von `prepare_assets.py` erzeugt), ob der
Key exakt existiert — Dateien mit Leerzeichen/Sonderzeichen im Namen bleiben
im Original-Key erhalten (z. B. `mediathek/single-image-overlay (alt,
description etc).png`), NICHT den `safe`-Namen als Key verwenden.

## Reihenfolge & fehlende Zuordnung

Wenn die `index.md` keine explizite Bild-Reihenfolge vorgibt, ordne die
Screenshots selbst didaktisch sinnvoll an (z. B. Login vor Dashboard-
Übersicht). Wenn ein in `index.md` erwähntes Bild in `image_map.json`
fehlt, nicht raten/erfinden — den Abschnitt ohne dieses Bild schreiben und
das im Chat kurz erwähnen (nicht die PDF-Erstellung deswegen blockieren).

---

# Ton & Stil für die Ziel­gruppe

Diese Schulungsunterlagen richten sich (sofern die `index.md` nichts
anderes sagt) an:
- Erwachsene mittleren Alters
- wenig bis keine WordPress-Vorerfahrung
- Ziel: selbstständig einfache Redaktionsaufgaben erledigen können

Daraus folgt:

1. **Kompakt, aber genau** — kurze Absätze (3–5 Sätze), aber keine
   Information weglassen, die zum Verständnis nötig ist. Lieber ein Satz
   mehr als eine Abkürzung, die Vorwissen voraussetzt.
2. **Keine unerklärten Fachbegriffe.** Jeder Fachbegriff (Taxonomie,
   Custom Post Type, Slug, ...) wird beim ersten Vorkommen in 1 Satz erklärt.
3. **Schritt-für-Schritt statt Prosa** bei Abläufen mit mehreren Klicks —
   `ul.check` oder nummerierte Listen nutzen, nicht alles in einen
   Fließtext-Absatz packen.
4. **Screenshots direkt nach der beschriebenen Aktion**, nicht gesammelt am
   Kapitelende — der Screenshot ist die Bestätigung "so sieht das bei dir
   dann aus".
5. **Callout `warning`** nur für Dinge, die beim Falschmachen wirklich
   Probleme verursachen (z. B. "keine eigenen Sections bauen"). Nicht
   inflationär einsetzen, sonst verliert es Wirkung.
6. **Direkte Anrede "ihr/euch"** (oder "du/dich", je nach Kunde — in
   `design-tokens.json` unter einem optionalen Feld `"tone"` prüfen, falls
   vorhanden, sonst beim Auftraggeber nachfragen bzw. das bestehende
   Kapitel-Beispiel in `f4t/` als Standard nehmen: "ihr/euch").

## Pflichtfeld-Konvention in Feldboxen

Wenn der Auftraggeber Felder als "Pflichtfeld" markiert, nutze konsequent
`<tr class="required">` (siehe components.md) statt das Wort "Pflichtfeld"
im Fließtext zu wiederholen — die CSS zeigt automatisch ein `*` an, plus
eine `<p class="legend">`-Fußnote am Ende der Box.
