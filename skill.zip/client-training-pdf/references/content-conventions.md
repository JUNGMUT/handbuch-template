# Konventionen für customer.md (Kunden-Briefing)

`customer.md` ist KEIN fertiger Text, sondern ein Briefing. Du (Claude) baust
daraus vollständige Kapitel im Stil der basic.pdf. Alles, was die Basis schon
erklärt, wird nicht wiederholt.

## Frontmatter

```yaml
---
kunde: Musterkunde GmbH     # Pflicht – Cover-Label + Dateiname
website: https://…          # optional, nur als Kontext (NICHT fürs Design)
anrede: ihr                 # ihr (Standard) | du | Sie
---
```

## Struktur → PDF

| customer.md                     | PDF                                                       |
|---------------------------------|-----------------------------------------------------------|
| `# Titel`                       | neues Kapitel, neue Seite, Nummer automatisch (10, 11 …), TOC-Eintrag |
| `## Titel`                      | Zwischenüberschrift `<h2>` im Kapitel                     |
| `## Titel {toc}`                | Unterkapitel (10.1 …), neue Seite, eigener TOC-Eintrag    |
| `### Titel`                     | `<h3>`                                                    |
| `1. 2. 3.` (nummerierte Liste)  | Schritt-für-Schritt `ul.check` (oder `<ol>`)              |
| `- Punkt`                       | `<ul>` bzw. `ul.check` bei Handlungsschritten             |
| `**fett**`                      | `<strong>` (Menüpunkte, Buttons, Feldnamen)               |
| `> **Tipp:** …`                 | `callout("tip", …)` (lila)                                |
| `> **Wichtig:** …`              | `callout("warning", …)` (blau)                            |
| `> **Gut zu wissen:** …`        | `callout("info", …)` (grün)                               |
| `FELDER: Titel` + `- Name* : Text` | `fieldbox(...)`, `*` = Pflichtfeld                     |
| Markdown-Tabelle `Bereich / Do / Don't` | `table.dosdonts` mit Badges                       |
| `<!-- … -->`                    | Notiz an dich – nie ins PDF übernehmen                    |

`{toc}` sparsam einsetzen: Das Inhaltsverzeichnis muss auf eine Seite passen.

## Das `AUSBAU:`-Prefix

Zeilen mit `AUSBAU:` / `AUSBAU (kurz):` / `AUSBAU (ausführlich):` baust du zu
vollständigen Absätzen aus — mit Kontext, ggf. Liste, ggf. Callout. Nicht nur
umformulieren.
- `(kurz)`: 2–4 Sätze.
- ohne Zusatz: 1–2 Absätze, ggf. Liste.
- `(ausführlich)`: mehrere Absätze/Zwischenüberschriften, Schritt-für-Schritt.

Text OHNE `AUSBAU:` ist vom Auftraggeber vorgegeben (Feldnamen, Menüpfade,
Pflicht-Status, Fakten) → inhaltlich exakt übernehmen, nur sprachlich glätten.
Nichts erfinden, was nicht im Briefing steht oder aus Screenshots ablesbar ist.
Ist etwas unklar und wichtig (z. B. widersprüchliche Feldangaben), am Ende im
Chat nachfragen statt raten.

## Bilder

- Syntax: `![Bildunterschrift](unterordner/datei.png)` — Pfad relativ zu `assets/`.
- Alt-Text = Bildunterschrift (→ `captions.json`). Leer → Caption aus Dateinamen.
- Zwei/mehr Bilder in derselben Zeile → `img_row(...)` nebeneinander.
- Optionaler Breiten-Hinweis direkt dahinter: `{schmal}` / `{mittel}` / `{voll}`
  → `width_class(...)` als `override_class`.
- Key immer gegen `image_map.json` prüfen (Leer-/Sonderzeichen bleiben im Key
  erhalten, NICHT den `safe`-Namen als Key verwenden).
- Bild steht direkt nach der beschriebenen Aktion, nicht gesammelt am Kapitelende.
- Bilder in `assets/`, die nirgends referenziert sind: didaktisch sinnvoll
  einbauen, wenn klar ist, wohin sie gehören — sonst weglassen und im Chat erwähnen.

## Bezug zur Basis

Die Basis-Kapitel (siehe `basic.json`) sind bekannt. Wenn ein Kundenkapitel
darauf aufbaut, verweise kurz („Grundlagen zu Custom Post Types: Kapitel 8.“)
und erkläre nur die Abweichung/Erweiterung beim Kunden.

---

# Ton & Stil für die Zielgruppe

Zielgruppe (sofern customer.md nichts anderes sagt): Redaktions-Anwender:innen,
wenig bis keine WordPress-Erfahrung, sollen einfache Aufgaben selbstständig
erledigen. Der Ton muss sich nahtlos an die basic.pdf anschließen.

1. **Kompakt, aber genau** — kurze Absätze (3–5 Sätze), keine nötige Info weglassen.
2. **Keine unerklärten Fachbegriffe** — beim ersten Vorkommen in 1 Satz erklären
   (sofern nicht schon in der Basis erklärt).
3. **Schritt-für-Schritt statt Prosa** bei Abläufen mit mehreren Klicks.
4. **Screenshots direkt nach der Aktion.**
5. **`warning`-Callout** nur für Dinge, die beim Falschmachen wirklich Probleme
   verursachen. Nicht inflationär.
6. **Anrede** laut Frontmatter `anrede` (Standard „ihr/euch“ wie in der Basis).
7. Typografische Anführungszeichen „…“, Gedankenstrich –, Pfeil → für Menüpfade
   (**Veranstaltungen → Neu hinzufügen**). Keine Emoji.

## Pflichtfelder

In Feldboxen Pflichtfelder über `required=True` (→ `<tr class="required">`)
kennzeichnen statt „Pflichtfeld“ im Text zu wiederholen; die Legende erscheint
automatisch.
