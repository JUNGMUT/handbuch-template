---
name: client-training-pdf
description: Erstellt ein gebrandetes Schulungs-PDF (WordPress/Elementor/CMS-Handbuch o.ä.) aus einem Kundenprojekt-Ordner mit index.md (Stichpunkte + AUSBAU:-Markierungen), Screenshots und design-tokens.json — die Design-Tokens kann der Skill selbst aus einem Website- oder Figma-Link extrahieren. Nutze diesen Skill IMMER, wenn der Nutzer ein Kunden-Schulungshandbuch, eine Anleitung, eine Onboarding-Unterlage oder ein Styleguide-PDF erstellen/aktualisieren will, einen Kundennamen nennt, der einen Ordner unter client-training-content/ hat, oder einen Website-/Figma-Link zum "Styleguide ziehen" nennt — auch wenn nur "das Handbuch für den Kunden" oder "PDF aktualisieren" gesagt wird, ohne dass explizit "Skill" erwähnt wird.
---

# Client Training PDF

Baut aus stichpunktartigen Vorgaben + Screenshots + Kunden-Design-Tokens ein
vollständiges, professionelles Schulungs-PDF im Corporate Design des Kunden.
Zielgruppe der erzeugten PDFs: Redaktions-Anwender mit wenig technischem
Vorwissen (siehe `references/content-conventions.md` für den genauen Ton).

Dieser Skill ist bewusst **kein Ein-Knopf-Skript** — das Ausformulieren der
Kapitel aus den Stichpunkten ist eine Schreibaufgabe, die du (Claude) pro
Kunde übernimmst. Die Skripte übernehmen nur die mechanischen Teile
(Bild-Aufbereitung, Farb-/Font-Einsetzung, PDF-Rendering).

## Voraussetzungen im Container

```bash
pip install weasyprint --break-system-packages -q
```
(Pillow ist i. d. R. schon vorhanden; falls nicht: `pip install Pillow --break-system-packages -q`)

## Erwartete Ordnerstruktur pro Kunde

```
client-training-content/<kunde>/
├── index.md              ← Briefing: Stichpunkte, AUSBAU:-Zeilen, Bildhinweise
├── design-tokens.json    ← Farben/Fonts/Radius (siehe f4t/ als Referenzbeispiel)
└── screenshots/
    └── <beliebige Unterordner>/*.png|jpg
```

Der Nutzer klont dafür EINMALIG das `client-training-content`-Repo, kopiert
`_template/` zu `<kunde>/` und befüllt `index.md` + `screenshots/` selbst.
`design-tokens.json` kann dabei leer/TODO bleiben — das ist Schritt 0.

## Workflow

### 0. Design-Tokens beschaffen (falls `design-tokens.json` noch TODOs enthält)
Der Nutzer nennt eine Quelle: einen **Website-Link** oder einen
**Figma-Link**. Lies `references/token-extraction.md` für das genaue
Vorgehen (Fetch-Strategie je nach Netzwerk-Allowlist, das
`parse_css_tokens.py`-Skript, und die Mapping-Regeln Report → JSON-Felder).
Kurzfassung:
- Website: relevante CSS-Dateien besorgen (per `web_fetch` oder `curl`,
  siehe Referenz) → `scripts/parse_css_tokens.py` drauf laufen lassen →
  Report interpretieren → `design-tokens.json` befüllen.
- Figma: Dev-Mode-MCP-Tools (`get_variable_defs` etc.) nutzen, falls
  verbunden; sonst Nutzer um Aktivierung bitten.

Bei Unsicherheit bei der Farbzuordnung (v. a. `primary`) lieber kurz
nachfragen als raten — falsche Zuordnung macht das PDF "off-brand".

### 1. Projekt lokalisieren
Ordner `client-training-content/<kunde>/` finden (oder vom Nutzer Pfad/Link
erfragen). `index.md` und `design-tokens.json` lesen.

### 2. Bilder aufbereiten
```bash
python3 <skill_root>/scripts/prepare_assets.py \
    client-training-content/<kunde>/screenshots \
    <output_dir>/assets \
    --map-out <output_dir>/image_map.json
```
Erzeugt `image_map.json` (Original-Pfad → sicherer Dateiname + Maße) und
skaliert/optimiert Bilder automatisch (Standard max. 1600px lange Kante —
hält PDF-Größe im Rahmen, siehe `--max-dim` zum Anpassen).

### 3. CSS + Fonts erzeugen
```bash
python3 <skill_root>/scripts/build_css.py \
    client-training-content/<kunde>/design-tokens.json \
    <output_dir>

python3 <skill_root>/scripts/setup_fonts.py \
    client-training-content/<kunde>/design-tokens.json \
    <output_dir>/assets
```
Ergebnis: `<output_dir>/style.css` sowie `<output_dir>/assets/fonts/{heading,body}.ttf`.
Bekannte Font-Kürzel in `design-tokens.json` → `fonts.heading.use_as` /
`fonts.body.use_as`: `"Sora"`, `"Inter"`. Für andere Marken-Fonts:
`--heading-file`/`--body-file` mit eigenem `.ttf`-Pfad übergeben (z. B. wenn
der Kunde eine lizenzierte Schrift bereitstellt).

### 4. Kapitel schreiben (der eigentliche Kern)
Lies `references/content-conventions.md` (AUSBAU:-Konvention, Ton/Stil) und
`references/components.md` (verfügbare HTML-Bausteine: Cover, Callouts,
Fieldbox, Do's/Don'ts-Tabelle, Bild-Einbindung) BEVOR du zu schreiben
beginnst.

Baue ein Python-Skript `<output_dir>/build_content.py`, das:
1. `from helpers import load_images, img, img_row` importiert
   (`sys.path` um `<skill_root>/scripts` erweitern)
2. Pro Kapitel aus `index.md` einen HTML-String erzeugt (Cover, ToC,
   `<section class="chapter">`-Blöcke) — siehe
   `client-training-content/f4t/index.md` + das daraus gebaute Ergebnis als
   Referenzbeispiel für Umfang/Detailgrad pro Kapitel
3. Alles zu einem `<!DOCTYPE html>`-Dokument zusammensetzt, das
   `<link rel="stylesheet" href="style.css">` referenziert
4. Das HTML nach `<output_dir>/content.html` schreibt

Bildunterschriften: Falls du bessere Captions als den automatischen
Dateiname-Fallback willst, schreibe sie nach `<output_dir>/captions.json`
(Format: `{"<safe-name-aus-image_map.json>": "Caption-Text"}`) und übergib
den Pfad an `load_images()`.

### 5. Rendern
```bash
python3 <skill_root>/scripts/render_pdf.py \
    <output_dir>/content.html \
    <output_dir>/<kunde>_Schulung.pdf \
    --base-url <output_dir>
```

### 6. Visuell prüfen (PFLICHT vor Auslieferung)
Mit `pdf2image` (`pip install pdf2image --break-system-packages -q`,
benötigt `poppler-utils`/`pdftoppm`, i. d. R. vorinstalliert) mind.
Cover, ein Textkapitel, ein bildlastiges Kapitel und jede Tabelle
(Fieldbox, Do's/Don'ts) als PNG rendern und mit `view` anschauen. Typische
Fehlerquellen, auf die explizit geachtet werden muss:
- Emoji in Tabellen (nicht gerendert) → immer `.badge`-Klassen statt ✅/❌
- Doppelter Footer auf dem Cover → `@page cover` muss
  `@bottom-left/@bottom-right { content: none; }` setzen (bereits in
  `style_base.css` enthalten, NICHT entfernen)
- Bildunterschrift fehlt/falsch → `captions.json` ergänzen
- Screenshot zu klein/unleserlich im Druck → `override_class="img-full"`
  erzwingen oder Nutzer auf zu kleine Quellauflösung hinweisen

### 7. Dateigröße prüfen
```bash
ls -la <output_dir>/<kunde>_Schulung.pdf
```
Über ~10 MB: `--max-dim` in Schritt 2 reduzieren (z. B. auf 1200) und Schritt
2+5 wiederholen.

### 8. Ausliefern
Nach `/mnt/user-data/outputs/` kopieren und mit `present_files` anzeigen
(siehe globale Anweisungen — dieser Schritt ist NICHT Teil dieses Skills,
sondern Standardverhalten für jede Dateiausgabe).

## Bestehendes Handbuch erweitern/ändern

- **Neue Screenshots:** einfach in den passenden Unterordner von
  `screenshots/` legen, Schritt 2 (`prepare_assets.py`) erneut laufen lassen
  — bestehende `image_map.json`-Keys bleiben stabil, solange Dateiname/Pfad
  gleich bleiben.
- **Screenshot ersetzen (gleicher Name):** Datei einfach überschreiben,
  Schritt 2 erneut laufen lassen.
- **`index.md` erweitern:** neue `AUSBAU:`-Zeilen/Kapitel ergänzen, dann nur
  Schritt 4 (die betroffenen Kapitel in `build_content.py` ergänzen) + 5 + 6
  wiederholen — Schritt 2/3 nur nötig, wenn sich Bilder oder Design-Tokens
  geändert haben.
- **Neuer Kunde:** Ordner nach dem Schema oben unter
  `client-training-content/<neuer-kunde>/` anlegen (Vorlage:
  `client-training-content/_template/`), dann kompletten Workflow ab
  Schritt 1 durchlaufen.

## Referenzdateien

- `references/token-extraction.md` — Design-Tokens aus Website-CSS oder
  Figma ableiten (Schritt 0): Fetch-Strategie, `parse_css_tokens.py`,
  Mapping-Regeln Report → design-tokens.json
- `references/content-conventions.md` — AUSBAU:-Konvention, Bild-Referenzen,
  Ton-/Stilrichtlinien für die Zielgruppe
- `references/components.md` — alle verfügbaren HTML-Bausteine mit
  Code-Beispielen (Cover, Callouts, Fieldbox, Do's/Don'ts, Bilder)
- `client-training-content/f4t/` — vollständiges, funktionierendes
  Referenzbeispiel (Briefing → fertiges PDF), an dem sich Umfang und
  Detailgrad orientieren sollten
