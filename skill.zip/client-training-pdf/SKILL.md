---
name: client-training-pdf
description: Erstellt das JUNGMUT WordPress-Redaktionshandbuch für einen Kunden — nimmt die fertige Basis (basic.pdf aus dem handbuch-template-Repo), generiert NUR die kundenspezifischen Zusatzkapitel aus customer.md (Stichpunkte + AUSBAU:-Markierungen) und den Screenshots in assets/, hängt sie an, erweitert das Inhaltsverzeichnis und hält alles im JUNGMUT-Design. Nutze diesen Skill IMMER, wenn der Nutzer ein Kunden-Handbuch, Schulungshandbuch, eine WordPress-Anleitung oder Onboarding-Unterlage erstellen/aktualisieren will, "das Handbuch mit den Erweiterungen bauen" sagt, eine customer.md erwähnt oder einen Kundennamen mit Handbuch/Schulung nennt — auch ohne das Wort "Skill".
---

# Client Training PDF (Basis + Kunden-Erweiterung)

Das Handbuch besteht aus zwei Teilen:

1. **Basis** – `basic.pdf` im handbuch-template-Repo. Fertig, generisch, deckt
   alles ab, was in jeder WordPress-Installation gleich ist (Login, Dashboard,
   Mediathek, Benutzer, Menüs, Gutenberg, Elementor, Do's & Don'ts, Blog,
   Custom Post Types, WPForms). **Wird nie neu generiert oder umgeschrieben.**
2. **Kunden-Erweiterung** – entsteht aus `customer.md` + `assets/`. Nur diese
   Kapitel schreibst du (Claude). Sie werden hinten angehängt und ab dem
   letzten Basis-Kapitel weiter nummeriert (Basis endet mit 9 → Kunde startet bei 10).

Das Design ist **immer JUNGMUT** (Unbounded + Nunito Sans, JM-Blau `#0030d0`,
JM-Grün `#9bd037`) – fest in `scripts/jungmut.css` verdrahtet und pixelgenau
auf die `basic.pdf` abgestimmt. **Niemals an Kundenfarben/-schriften
anpassen**, auch wenn customer.md eine Website verlinkt.

## Repo-Struktur (pro Kunde eine Kopie des Templates)

```
<kunden-repo>/
├── basic.pdf        ← Basis-Handbuch (nicht anfassen)
├── basic.json       ← Kapitel-Manifest der basic.pdf (Nummern, Titel, Seiten, Cover-Label)
├── customer.md      ← Kunden-Briefing: Frontmatter + Kapitel (Konventionen: references/content-conventions.md)
├── assets/          ← Screenshots, beliebige Unterordner, referenziert aus customer.md
├── build/           ← Zwischendateien (gitignored, darfst du frei anlegen)
└── output/          ← fertiges PDF: <Kunde>_Handbuch.pdf
```

Fallback: Gibt es keine `customer.md`, aber eine `index.md` mit Kundeninhalten,
diese verwenden.

## Voraussetzungen

```bash
pip install weasyprint pypdf Pillow --break-system-packages -q
```
`pdftoppm` / `pdftotext` (poppler-utils) für Vorschau und Prüfung.

**Wo bauen?** Liegt das Repo auf dem Rechner des Nutzers (verbundener Ordner)
und ist WeasyPrint dort nicht installierbar: `customer.md`, `basic.pdf`,
`basic.json` und alle Dateien unter `assets/` in den Container holen, dort
bauen und am Ende **nur** das fertige PDF nach `<repo>/output/` zurückschreiben.
Im Claude-Code-CLI direkt im Repo arbeiten.

## Workflow

`<skill>` = Ordner dieses Skills, `<repo>` = Kunden-Repo, `<build>` = `<repo>/build`.

### 1. Briefing lesen
- `customer.md` komplett lesen, inkl. Frontmatter (`kunde`, `anrede`, optional
  `website`). Fehlt `kunde`, kurz nachfragen (wird für Cover und Dateiname gebraucht).
- `basic.json` lesen → Liste der Basis-Kapitel + letzte Kapitelnummer.
- `references/content-conventions.md` und `references/components.md` lesen,
  BEVOR du schreibst.
- **Überschneidungen prüfen:** Wiederholt customer.md etwas, das schon in der
  Basis steht (Kapitelliste in basic.json), nicht nochmal erklären — nur das
  Kundenspezifische schreiben und auf das Basis-Kapitel verweisen
  („Wie ihr Seiten mit Elementor bearbeitet, steht in Kapitel 5.“).

### 2. Design + Bilder vorbereiten
```bash
python3 <skill>/scripts/setup_build.py <build>
python3 <skill>/scripts/prepare_assets.py <repo>/assets <build>/assets --map-out <build>/image_map.json
```
`image_map.json`-Keys = Pfade relativ zu `assets/` (genau so, wie sie in
customer.md stehen). Fehlt ein referenziertes Bild: Abschnitt ohne Bild
schreiben und es am Ende im Chat erwähnen, nicht abbrechen.

### 3. Kunden-Kapitel schreiben (der eigentliche Kern)
Schreibe `<build>/build_content.py`, das mit den Helpern aus
`<skill>/scripts/helpers.py` (`chapter`, `img`, `img_row`, `callout`,
`fieldbox`, `document`, `width_class`) **nur die Kunden-Kapitel** erzeugt und
nach `<build>/content.html` schreibt. Regeln:
- Kein Cover, kein Inhaltsverzeichnis – die kommen aus basic.pdf bzw. assemble.py.
- Jedes `# Kapitel` aus customer.md → `chapter("<n>", "Titel", body)`, Nummer
  fortlaufend ab letzter Basis-Nummer + 1.
- `## Titel {toc}` → eigenes Unterkapitel `chapter("<n>.1", …)` direkt nach dem
  Elternkapitel (neue Seite, eigener TOC-Eintrag). Normale `##` → `<h2>`, `###` → `<h3>`.
- Bildunterschriften: Alt-Text aus customer.md in `<build>/captions.json`
  (`{"<safe-name>": "Caption"}`) oder direkt ins `CAPTIONS`-Dict.
- Ton, Anrede und AUSBAU-Regeln: `references/content-conventions.md`.

```bash
python3 <build>/build_content.py
```

### 4. Zusammenbauen
```bash
python3 <skill>/scripts/assemble.py \
    --basic   <repo>/basic.pdf \
    --content <build>/content.html \
    --client  "<kunde aus Frontmatter>" \
    --out     <repo>/output/<Kunde>_Handbuch.pdf
```
Das Skript
- rendert die Kunden-Kapitel mit nahtlos weiterlaufender Seitenzahl,
- baut das Inhaltsverzeichnis neu (Basis + Kunde, identisches Layout wie
  basic.pdf; bei vielen Einträgen automatisch enger gesetzt, bleibt 1 Seite),
- ersetzt auf dem Cover „Schulungsunterlage · Basisversion“ durch
  „Schulungsunterlage · <Kunde>“ (abschaltbar mit `--no-cover-label`),
- setzt PDF-Lesezeichen und Titel-Metadaten,
- gibt eine JSON-Zusammenfassung aus (Seiten, Kapitel, Größe). `[WARNUNG]`-
  Zeilen ernst nehmen (z. B. falsche Startnummer).

### 5. Visuell prüfen (PFLICHT)
```bash
pdftoppm -r 60 -png -f 1 -l 2 <out.pdf> <build>/check                 # Cover + TOC
pdftoppm -r 60 -png -f <erste Kundenseite> <out.pdf> <build>/check    # alle Kundenseiten
```
Die PNGs ansehen. Achten auf:
- Cover-Label sauber ersetzt (kein Rest von „Basisversion“ sichtbar)
- TOC: alle Kunden-Kapitel da, Nummerierung lückenlos
- Kunden-Seiten optisch wie die Basis (Überschriften, Footer „Seite N“ läuft weiter)
- Keine Emoji (werden nicht gerendert → `.badge`-Klassen nutzen)
- Screenshots lesbar, Captions korrekt, keine halbleeren Seiten durch zu
  große Bilder (ggf. `override_class="img-medium"`)

### 6. Größe + Auslieferung
Über ~15 MB: `prepare_assets.py` mit `--max-dim 1200` erneut laufen lassen,
Schritt 3–4 wiederholen. Das PDF liegt in `<repo>/output/`; dem Nutzer Pfad,
Seitenzahl und Liste der neuen Kapitel nennen, plus fehlende Bilder/offene Fragen.

## Änderungen später
- **customer.md geändert:** nur Schritt 3–5 (Schritt 2 nur bei neuen/geänderten Bildern).
- **Neue Basis-Version:** neue `basic.pdf` ins Template-Repo + `basic.json`
  aktualisieren (Kapitel-Seiten, `pages`). Fehlt `basic.json`, liest
  assemble.py die Kapitel automatisch aus der basic.pdf (große
  Kapitelüberschriften) – das Manifest ist aber verlässlicher.
- **Design-Änderung:** nur in `scripts/jungmut.css` – und dann auch die
  basic.pdf mit demselben CSS neu bauen, sonst passen Basis und Erweiterung
  nicht mehr zusammen.

## Referenzdateien
- `references/content-conventions.md` — Aufbau der customer.md, AUSBAU-Regeln,
  Bild-/Box-/Feld-Syntax, Ton für die Zielgruppe
- `references/components.md` — HTML-Bausteine + Helper-Funktionen
- `scripts/jungmut.css` — festes JUNGMUT-Design
- `scripts/assemble.py` — Merge, TOC, Cover-Label, Lesezeichen
